<?php
    class Db_model extends CI_Model {
        function return_menu() {
            $this->load->database();
            $query = $this->db->query("SELECT * FROM menu");
            $query->result_array();
            return $query->result_array();
        }
    }
?>