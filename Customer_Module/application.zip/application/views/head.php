<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo base_url().'css/bootstrap.css' ?>" type="text/css">
<link rel="stylesheet" href="<?php echo base_url().'css/bootstrap.min.css' ?>" type="text/css">
<link rel="stylesheet" href="<?php echo base_url().'css/style.css' ?>" type="text/css">
<link rel="icon" href="<?php echo base_url().'logo.png' ?>">