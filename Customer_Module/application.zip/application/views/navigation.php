<div class="nav nav-pills">
    <div class="logo"><img src="<?php echo base_url().'logo.png' ?>"></div>
    <div class="illengan">Welcome to Il-Lengan</div>
    <div class="nav-menu">Menu</div>
    <div class="nav-orders">Orders</div>
</div>