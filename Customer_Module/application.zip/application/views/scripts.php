  <!-- JQuery -->
  <script type="text/javascript" src="<?php echo base_url().'js/jquery-3.3.1.min.js' ?>"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="<?php echo base_url().'js/popper.min.js' ?>"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="<?php echo base_url().'js/bootstrap.min.js' ?>"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="<?php echo base_url().'js/mdb.min.js' ?>"></script>
  <script type="text/javascript" src="<?php echo base_url().'js/indec.js' ?>"></script>